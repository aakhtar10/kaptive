
import BarChart from "./pages/BarChart";
import SalesTable from "./pages/SalesTable";




const App = () => {
  
  
  return (
    <div>
     <BarChart/>
  <SalesTable/>
    </div>
  );
};

export default App;
